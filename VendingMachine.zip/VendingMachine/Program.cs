﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
    public enum COIN
    {
        Invalid = 0,
        Nickels = 1,
        Dimes = 2,
        Quarters = 3
    }
    public static class Coin
    {
        public static double TotalValue = 0;
        public const double nickels_CoinValue = 0.05;
        public const double dimes_CoinValue = 0.1;
        public const double quarters_CoinValue = 0.25;
        public static double addCoin(COIN coin)
        {
            switch (coin)
            {
                case COIN.Nickels:
                    return TotalValue += nickels_CoinValue;
                case COIN.Dimes:
                    return TotalValue += dimes_CoinValue;
                case COIN.Quarters:
                    return TotalValue += quarters_CoinValue;
                default: return TotalValue;
            }
        }
    }
    public sealed class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public double Price { get; set; }
    }
    public class VenderProducts
    {
        List<Product> products;
        public void ProductsList()
        {
            products = new List<Product>() {
                new Product() { ProductId = 1,ProductName = "cola", Price = 1 },
                new Product() { ProductId = 2,ProductName = "chips", Price = 0.5 },
                new Product() { ProductId = 3,ProductName = "candy", Price = 0.65 }

            };
        }
        public void ShowProductList()
        {
            foreach (Product product in products)
            {
                Console.WriteLine("{0} for {1} Price : {2}", product.ProductId, product.ProductName, product.Price);
            }
        }
        public List<Product> GetProductList()
        {
            return products;
        }
        public Product ChooseProduct()
        {
            int selectedProductId;
            int.TryParse(Console.ReadLine(), out selectedProductId);
            if (selectedProductId == 0 || (!products.Exists(p => p.ProductId == selectedProductId)))
            {
                Console.WriteLine("Please Choose Valid Product from below list");
                ShowProductList();
                return ChooseProduct();
            }
            else
            {
                return products.Find(p => p.ProductId == selectedProductId);
            }
        }

    }

    public class Program
    {

        public static double InsertCoin()
        {

            Console.WriteLine("Enter Nickels coin for 1");
            Console.WriteLine("Enter Dimes coin for 2");
            Console.WriteLine("Enter Quarters coin for 3");

            COIN selectedCoin;
            Enum.TryParse(Console.ReadLine(), out selectedCoin);
            if (selectedCoin == COIN.Invalid)
            {
                Console.WriteLine("Invalid Coin Entered, INSERT COIN");
                return InsertCoin();
            }
            else
            {
                return Coin.addCoin(selectedCoin);
            }

        }
        static void Main(string[] args)
        {
            VenderProducts venderProducts = new VenderProducts();
            venderProducts.ProductsList();
            Console.WriteLine("Please Choose Valid Product from below list");
            venderProducts.ShowProductList();
            Product selectedProduct = venderProducts.ChooseProduct();
            Console.WriteLine("Your Product is : {0} and Price : {1}", selectedProduct.ProductName, selectedProduct.Price);

            Console.WriteLine("Insert Coin");
            double totalInsertedAmount = 0;
            while (totalInsertedAmount <= selectedProduct.Price)
            {
                totalInsertedAmount = InsertCoin();
                Console.WriteLine("Total inserted amount: {0}, Remaining to Pay amount: {1}", totalInsertedAmount, (selectedProduct.Price - totalInsertedAmount));
            }
            Console.WriteLine("Congrats!!! your selected {0} is Ready, Your Balance: {1}", selectedProduct.ProductName, (selectedProduct.Price - totalInsertedAmount));
            Console.ReadLine();

        }
    }
}


     